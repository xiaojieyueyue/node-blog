INSERT INTO `user` (`id`, `name`, `password`, `email`, `birthday`, `sex`) VALUES (1, '134679', '134679', '123465@qq.com', '2020211', '男');
INSERT INTO `user` (`id`, `name`, `password`, `email`, `birthday`, `sex`) VALUES (2, '258022580', '25802580', '123123@163.com', '男', '2020-01-31');
INSERT INTO `user` (`id`, `name`, `password`, `email`, `birthday`, `sex`) VALUES (3, '134679', '134679', '132132@163.com', '', '');
INSERT INTO `user` (`id`, `name`, `password`, `email`, `birthday`, `sex`) VALUES (4, '132123', '123123', '123@163.com', '', '');
INSERT INTO `user` (`id`, `name`, `password`, `email`, `birthday`, `sex`) VALUES (6, '123456789', '123465789', '', '', '');
INSERT INTO `user` (`id`, `name`, `password`, `email`, `birthday`, `sex`) VALUES (10, '000000', '000000', '123@163.com', '', '');
